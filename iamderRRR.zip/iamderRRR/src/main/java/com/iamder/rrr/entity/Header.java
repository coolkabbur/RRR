package com.iamder.rrr.entity;

public class Header {
	
	private String result;
	private String txnId;
	private String status;
	
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getTxnId() {
		return txnId;
	}
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Header [result=" + result + ", txnId=" + txnId + ", status=" + status + "]";
	}
	
	
	
	
}
