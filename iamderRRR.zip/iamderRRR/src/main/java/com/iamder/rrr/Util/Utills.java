package com.iamder.rrr.Util;

import java.sql.Timestamp;

public class Utills
{

	public String genrateTxnId ()
	{
		return new Timestamp ( System.currentTimeMillis () ).toString ();
	}

	public static boolean isNullOrEmpty ( String str )
	{
		if ( str != null && !str.isEmpty () )
			return true;
		return false;
	}

}
