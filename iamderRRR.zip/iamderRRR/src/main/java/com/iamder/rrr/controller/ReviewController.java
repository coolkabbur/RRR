package com.iamder.rrr.controller;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.ws.rs.QueryParam;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.iamder.rrr.Util.Utills;
import com.iamder.rrr.entity.ItemEntity;
import com.iamder.rrr.entity.ReviewEntity;
import com.iamder.rrr.service.ReviewService;

@RestController
@RequestMapping ( "/review" )
public class ReviewController
{

	@Autowired
	private ReviewService reviewService;

	@PostMapping ( value = "/test" )
	public String testDynamoDB ()
	{
		return "Hai Iamder";
	}

	@PostMapping ( value = "/add" )
	public Object addReview ( @RequestBody Map <Object, Object> reviewRequest, @QueryParam ( "auth_id" ) String auth_id )
	{

		ReviewEntity reviewEntity = null;
		Integer httpStatus = 200;
		// Response content
		JSONObject resJson = new JSONObject ();
		// Response Header
		JSONObject resHeader = new JSONObject ();
		// Response Data
		JSONObject resData = new JSONObject ();

		try
		{
			if ( reviewRequest != null )
			{
				ObjectMapper mapper = new ObjectMapper ();
				reviewEntity = mapper.convertValue ( reviewRequest, ReviewEntity.class );
				if ( reviewEntity != null )
				{
					reviewEntity.setTxnId ( UUID.randomUUID().toString() );
					reviewEntity.setCreatedDate ( new Timestamp ( System.currentTimeMillis () ).toString () );
					reviewEntity = reviewService.addReview ( reviewEntity );
					if ( reviewEntity != null )
					{
						// Success 
						resHeader.put ( "result", "5000" );
						resHeader.put ( "status", "Success" );
						resHeader.put ( "txid", reviewEntity.getTxnId ().toString () );
						resData.put ( "reviewId", reviewEntity.getReviewId () );
					}
					else
					{
						// Not Save
						resHeader.put ( "result", "8002" );
						resHeader.put ( "status", "Internal Server Error" );
						resHeader.put ( "txid", System.currentTimeMillis () );
						httpStatus = 404;
					}

				}
				else
				{
					// commit Error
					resHeader.put ( "result", "8002" );
					resHeader.put ( "status", "Internal Server Error" );
					resHeader.put ( "txid", UUID.randomUUID().toString() );
					httpStatus = 404;
				}
			}
			else
			{
				// Wrong Request
				resHeader.put ( "result", "8002" );
				resHeader.put ( "status", "Wrong Request" );
				resHeader.put ( "txid",UUID.randomUUID().toString());
				httpStatus = 404;
			}
			// Final Response Json
			resJson.put ( "header", resHeader );
			resJson.put ( "data", resData );

		}
		catch ( Exception e )
		{
			// TODO: handle exception
		}
		return resJson.toString ();
		//return Response.status(httpStatus).entity(resJson.toString()).build();

	}

	@GetMapping ( value = "/item/{itemId}" )
	public Object getReviewByItemId ( @PathVariable ( "itemId" ) String itemId, @QueryParam ( "auth_id" ) String auth_id, @QueryParam ( "Offset" ) String Offset, @QueryParam ( "LoadLimit" ) String LoadLimit )
	{

		List <ReviewEntity> reviewEntityList = null;
		Integer httpStatus = 200;
		// Response content
		JSONObject resJson = new JSONObject ();
		// Response Header
		JSONObject resHeader = new JSONObject ();
		// Response Data
		JSONObject resData = new JSONObject ();

		try
		{
			if ( Utills.isNullOrEmpty ( itemId ) )
			{
				reviewEntityList = reviewService.getReviewByItemId ( itemId );
               
				resHeader.put ( "result", "5000" );
				resHeader.put ( "status", "Success" );
				resHeader.put ( "txid", UUID.randomUUID().toString() );

				resData.put ( "reviews", reviewEntityList );
			}
			else
			{
				resHeader.put ( "result", "8002" );
				resHeader.put ( "status", "ItemId is not Null" );
				resHeader.put ( "txid", UUID.randomUUID().toString() );
				httpStatus = 404;
			}
			// Final Response Json
			resJson.put ( "header", resHeader );
			resJson.put ( "data", resData );

		}
		catch ( Exception e )
		{
			// TODO: handle exception
		}

		return resJson.toString ();
	}

	@GetMapping ( value = "/item/count/{itemId}" )
	public Object getReviewCountByItemId ( @PathVariable ( "itemId" ) String itemId,@QueryParam("auth_id") String auth_id )
	{

		Integer count = 0;
		Integer httpStatus = 200;
		// Response content
		JSONObject resJson = new JSONObject ();
		// Response Header
		JSONObject resHeader = new JSONObject ();
		// Response Data
		JSONObject resData = new JSONObject ();

		try
		{
			if ( Utills.isNullOrEmpty ( itemId ) )
			{
				count = reviewService.getReviewCountByItemId ( itemId );

				resHeader.put ( "result", "5000" );
				resHeader.put ( "status", "Success" );
				resHeader.put ( "txid",UUID.randomUUID().toString() );

				resData.put ( "count", count );
			}
			else
			{
				resHeader.put ( "result", "8002" );
				resHeader.put ( "status", "ItemId is not Null" );
				resHeader.put ( "txid", UUID.randomUUID().toString() );
				httpStatus = 404;
			}
			// Final Response Json
			resJson.put ( "header", resHeader );
			resJson.put ( "data", resData );

		}
		catch ( Exception e )
		{
			// TODO: handle exception
		}

		return resJson.toString ();
	}
	
	
	@GetMapping ( value = "/average/{itemId}" )
	public Object getReviewAverageByItemId ( @PathVariable ( "itemId" ) String itemId,@QueryParam("auth_id") String auth_id )
	{

		Integer count = 0;
		Integer httpStatus = 200;
		// Response content
		JSONObject resJson = new JSONObject ();
		// Response Header
		JSONObject resHeader = new JSONObject ();
		// Response Data
		JSONObject resData = new JSONObject ();

		ItemEntity itemEntity = null;
		try
		{
			if ( Utills.isNullOrEmpty ( itemId ) )
			{
				List <ReviewEntity> reviewEntityList = reviewService.getReviewAverageByItemId ( itemId );
				
				if(!reviewEntityList.isEmpty () &&reviewEntityList.size ()>0)
				{
					itemEntity= new ItemEntity ();
					itemEntity=reviewEntityList.get ( 0 ).getItem ();			
					for(ReviewEntity reviewEntity:reviewEntityList)
					{
						count+=Integer.valueOf (reviewEntity.getRating ());
					}
					resHeader.put ( "result", "5000" );
					resHeader.put ( "status", "Success" );
					resHeader.put ( "txid", reviewEntityList.get ( 0 ).getTxnId () );

					resData.put ( "average",  (Double.valueOf (count )/Double.valueOf(reviewEntityList.size ())) );
					resData.put ( "item", new JSONObject(new ObjectMapper().writeValueAsString(itemEntity)));
					
				}else
				{
					resHeader.put ( "result", "5000" );
					resHeader.put ( "status", "There is no Item" );
					resHeader.put ( "txid", UUID.randomUUID().toString() );

					resData.put ( "average",  (Double.valueOf (count )/Double.valueOf(reviewEntityList.size ())) );
					resData.put ( "item",itemEntity  );
				}
				
			}
			else
			{
				resHeader.put ( "result", "8002" );
				resHeader.put ( "status", "ItemId is not Null" );
				resHeader.put ( "txid", new Timestamp ( System.currentTimeMillis () ).toString () );
				httpStatus = 404;
			}
			// Final Response Json
			resJson.put ( "header", resHeader );
			resJson.put ( "data", resData );

		}
		catch ( Exception e )
		{
			// TODO: handle exception
			System.err.println ( e.toString () );
		}

		return resJson.toString ();
	}
	
	
	//Get Top Rated Profile
	@GetMapping ( value = "/top/{itemId}" )
	public Object getTopRatedProfileByItemId ( @PathVariable ( "itemId" ) String itemId,@QueryParam("auth_id") String auth_id )
	{
		Integer count = 0;
		Integer httpStatus = 200;
		// Response content
		JSONObject resJson = new JSONObject ();
		// Response Header
		JSONObject resHeader = new JSONObject ();
		// Response Data
		JSONObject resData = new JSONObject ();

		ItemEntity itemEntity = null;
		try
		{
			if ( Utills.isNullOrEmpty ( itemId ) )
			{
				
				
			}
			else
			{
				resHeader.put ( "result", "8002" );
				resHeader.put ( "status", "ItemId is not Null" );
				resHeader.put ( "txid", UUID.randomUUID().toString() );
				httpStatus = 404;
			}
			// Final Response Json
			resJson.put ( "header", resHeader );
			resJson.put ( "data", resData );

		}
		catch ( Exception e )
		{
			// TODO: handle exception
			System.err.println ( e.toString () );
		}

		return resJson.toString ();
	}
	
	//Get Top Rated Profile
		@GetMapping ( value = "/lowest/{itemId}" )
		public Object getLowestRatedProfileByItemId ( @PathVariable ( "itemId" ) String itemId,@QueryParam("auth_id") String auth_id )
		{
			Integer count = 0;
			Integer httpStatus = 200;
			// Response content
			JSONObject resJson = new JSONObject ();
			// Response Header
			JSONObject resHeader = new JSONObject ();
			// Response Data
			JSONObject resData = new JSONObject ();

			ItemEntity itemEntity = null;
			try
			{
				if ( Utills.isNullOrEmpty ( itemId ) )
				{
					
					
				}
				else
				{
					resHeader.put ( "result", "8002" );
					resHeader.put ( "status", "ItemId is not Null" );
					resHeader.put ( "txid", UUID.randomUUID().toString() );
					httpStatus = 404;
				}
				// Final Response Json
				resJson.put ( "header", resHeader );
				resJson.put ( "data", resData );

			}
			catch ( Exception e )
			{
				// TODO: handle exception
				System.err.println ( e.toString () );
			}

			return resJson.toString ();
		}
	

}
