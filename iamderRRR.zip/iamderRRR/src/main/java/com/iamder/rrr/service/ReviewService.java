package com.iamder.rrr.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iamder.rrr.entity.ReviewEntity;
import com.iamder.rrr.repository.ReviewRepository;

@Service
public class ReviewService
{

	@Autowired
	private ReviewRepository repository;

	public ReviewEntity addReview ( ReviewEntity review )
	{

		ReviewEntity reviewEntity = null;
		try
		{
			reviewEntity = repository.addReview ( review );

		}
		catch ( Exception e )
		{
			// TODO: handle exception
		}
		return reviewEntity;
	}

	public List <ReviewEntity> getReviewByItemId ( String itemId )
	{

		List <ReviewEntity> reviewEntityList = null;
		try
		{
			reviewEntityList = repository.getReviewByItemId ( itemId );

		}
		catch ( Exception e )
		{
			// TODO: handle exception
		}
		return reviewEntityList;
	}

	public Integer getReviewCountByItemId ( String itemId )
	{
		try
		{
			return repository.getReviewCountByItemId ( itemId );

		}
		catch ( Exception e )
		{
			// TODO: handle exception
		}
		return null;
	}

	public List <ReviewEntity> getReviewAverageByItemId ( String itemId )
	{

		List <ReviewEntity> reviewEntityList = null;
		try
		{
			reviewEntityList = repository.getReviewByItemId ( itemId );

		}
		catch ( Exception e )
		{
			// TODO: handle exception
		}
		return reviewEntityList;
	}
}
