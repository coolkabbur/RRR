package com.iamder.rrr.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBSaveExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ComparisonOperator;
import com.amazonaws.services.dynamodbv2.model.ExpectedAttributeValue;
import com.iamder.rrr.entity.ReviewEntity;

@Repository
public class ReviewRepository
{

	private static final Logger	LOGGER	= LoggerFactory.getLogger ( ReviewRepository.class );

	@Autowired
	private DynamoDBMapper		mapper;

	public ReviewEntity addReview ( ReviewEntity review )
	{
		try
		{
			mapper.save ( review );
		}
		catch ( Exception e )
		{
			LOGGER.error ( e.toString () );
			return null;
		}
		return review;
	}

	public ReviewEntity getReviewByReviewId ( String reviewId )
	{
		ReviewEntity reviewEntity = null;
		try
		{
			reviewEntity = mapper.load ( ReviewEntity.class, reviewId );
		}
		catch ( Exception e )
		{
			LOGGER.error ( e.toString () );
		}
		return reviewEntity;
	}

	public List <ReviewEntity> getReviewByItemId ( String itemId )
	{

		List <ReviewEntity> reviewEntityList = null;
		try
		{
			Map <String, AttributeValue> expressionAttributeValues = new HashMap <String, AttributeValue> ();
			expressionAttributeValues.put ( ":val", new AttributeValue ().withS ( itemId ) );

			DynamoDBScanExpression scanExpression = new DynamoDBScanExpression ();
			scanExpression.withFilterExpression ( "reviewItem.itemId=:val" ).withExpressionAttributeValues ( expressionAttributeValues );
			reviewEntityList = mapper.scan ( ReviewEntity.class, scanExpression );

			/*Map<String, AttributeValue> expressionAttributeValues = 
				    new HashMap<String, AttributeValue>();
				expressionAttributeValues.put(":val", new AttributeValue().withS("2221")); 
				        
				ScanRequest scanRequest = new ScanRequest()
				    .withTableName("Review")
				    .withFilterExpression("reviewItem.itemId=:val")
				    .withExpressionAttributeValues(expressionAttributeValues);
			
				ScanResult result = client.scan(scanRequest);
				for (Map<String, AttributeValue> item : result.getItems()) {
				    System.out.println(item.toString());
				    System.out.println();
				}*/

		}
		catch ( Exception e )
		{
			LOGGER.error ( e.toString () );
		}
		return reviewEntityList;
	}

	public Integer getReviewCountByItemId ( String itemId )
	{

		List <ReviewEntity> reviewEntityList = null;
		Integer count=0;
		try
		{
			Map <String, AttributeValue> expressionAttributeValues = new HashMap <String, AttributeValue> ();
			expressionAttributeValues.put ( ":val", new AttributeValue ().withS ( itemId ) );

			DynamoDBScanExpression scanExpression = new DynamoDBScanExpression ();
			scanExpression.withFilterExpression ( "reviewItem.itemId=:val" )
			.withExpressionAttributeValues ( expressionAttributeValues );
			//.withProjectionExpression ( "rating" );
			reviewEntityList = mapper.scan ( ReviewEntity.class, scanExpression );
			/*for(ReviewEntity reviewEntity:reviewEntityList)
			{
				count+=Integer.valueOf (reviewEntity.getRating ());
			}*/
			count=reviewEntityList.size ();
         
		}
		catch ( Exception e )
		{
			LOGGER.error ( e.toString () );
		}
		return count;
	}
	
	
	public List <ReviewEntity> getReviewAverageByItemId ( String itemId )
	{

		List <ReviewEntity> reviewEntityList = null;
		try
		{
			Map <String, AttributeValue> expressionAttributeValues = new HashMap <String, AttributeValue> ();
			expressionAttributeValues.put ( ":val", new AttributeValue ().withS ( itemId ) );

			DynamoDBScanExpression scanExpression = new DynamoDBScanExpression ();
			scanExpression.withFilterExpression ( "reviewItem.itemId=:val" ).withExpressionAttributeValues ( expressionAttributeValues )
			.withProjectionExpression ( "rating,reviewItem" );;
			reviewEntityList = mapper.scan ( ReviewEntity.class, scanExpression );

		}
		catch ( Exception e )
		{
			LOGGER.error ( e.toString () );
		}
		return reviewEntityList;
	}

	public List <ReviewEntity> getTopRatedProfileByItemId ( String itemId )
	{

		List <ReviewEntity> reviewEntityList = null;
		try
		{
			Map <String, AttributeValue> expressionAttributeValues = new HashMap <String, AttributeValue> ();
			expressionAttributeValues.put ( ":val", new AttributeValue ().withS ( itemId ) );

			DynamoDBScanExpression scanExpression = new DynamoDBScanExpression ();
			scanExpression.withFilterExpression ( "reviewItem.itemId=:val" ).withExpressionAttributeValues ( expressionAttributeValues )
			.withProjectionExpression ( "rating,reviewItem" );;
			reviewEntityList = mapper.scan ( ReviewEntity.class, scanExpression );

		}
		catch ( Exception e )
		{
			LOGGER.error ( e.toString () );
		}
		return reviewEntityList;
	}
	
	public List <ReviewEntity> getLowestRatedProfileByItemId ( String itemId )
	{

		List <ReviewEntity> reviewEntityList = null;
		try
		{
			Map <String, AttributeValue> expressionAttributeValues = new HashMap <String, AttributeValue> ();
			expressionAttributeValues.put ( ":val", new AttributeValue ().withS ( itemId ) );

			DynamoDBScanExpression scanExpression = new DynamoDBScanExpression ();
			scanExpression.withFilterExpression ( "reviewItem.itemId=:val" ).withExpressionAttributeValues ( expressionAttributeValues )
			.withProjectionExpression ( "rating,reviewItem" );;
			reviewEntityList = mapper.scan ( ReviewEntity.class, scanExpression );

		}
		catch ( Exception e )
		{
			LOGGER.error ( e.toString () );
		}
		return reviewEntityList;
	}
	
	
	
	public ReviewEntity deleteReview ( ReviewEntity reviewEntity )
	{
		ReviewEntity review = null;
		try
		{
			mapper.delete ( reviewEntity );
		}
		catch ( Exception e )
		{
			LOGGER.error ( e.toString () );
		}
		return reviewEntity;
	}

	public List <ReviewEntity> getReviews ()
	{
		List <ReviewEntity> reviews = null;
		try
		{
			// mapper.delete(reviewEntity);
		}
		catch ( Exception e )
		{
			LOGGER.error ( e.toString () );
		}
		return reviews;
	}

	public DynamoDBSaveExpression buildDynamoDBSaveExpression ( ReviewEntity review )
	{
		DynamoDBSaveExpression saveExpression = new DynamoDBSaveExpression ();
		Map <String, ExpectedAttributeValue> expected = new HashMap <> ();
		expected.put ( "reviewId", new ExpectedAttributeValue ( new AttributeValue ( review.getReviewId () ) ).withComparisonOperator ( ComparisonOperator.EQ ) );
		saveExpression.setExpected ( expected );
		return saveExpression;
	}

}
